import os
import boto3
import json

from get_json_response import get_json_response


URL = "https://data.police.uk/api/crime-last-updated"

LANDING_BUCKET = os.environ['S3_LANDING_ID']


# def lambda_handler(event, context):
#     """
#     Lambda handler function for data update check 
#     """
#     client = boto3.client('s3')
#     last_updated_date_object= client.get_object(Bucket=LANDING_BUCKET,Key='last_updated_date.json')
#     response_status, response_body = get_json_response(URL)
#     if response_status == 200 and response_body['date'] != current_updated_date:


#     return {'statusCode': 200}

if __name__ == "__main__":
    client = boto3.client('s3')
    last_updated_date_object= client.get_object(Bucket=LANDING_BUCKET,Key='last_updated_date.json') 
    #last_updated_date = last_updated_date_object['date']
    print(last_updated_date_object)
    last_updated_date_json = last_updated_date_object['Body'].read().decode('utf-8')
    #print(last_updated_date)
    print(last_updated_date_json)
    last_updated_date_dict = json.loads(last_updated_date_json)
    print(last_updated_date_dict)
    last_updated_date = last_updated_date_dict.name
    print(last_updated_date)